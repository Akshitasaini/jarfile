package com.tweet.entity;

//
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;


import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAutoGenerateStrategy;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBGeneratedUuid;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@DynamoDBTable(tableName="upload_media")
public class UploadMedia {

	//@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String id;
	private String uid;
	private String title;
	private String description;
	private String tags;
	
	private String date;
	private String username;
	  
     
	public UploadMedia(String id, String uid, String title, String description, String tags) {
		super();
		this.id = id;
		this.uid = uid;
		this.title = title;
		this.description = description;
		this.tags = tags;
		
	}


	public UploadMedia(String uid, String title, String description, String tags,String date,String username) {
		super();
		this.uid = uid;
		this.title = title;
		this.description = description;
		this.tags = tags;
		
		this.username = username;
		this.setDate(date);
		//this.currentDate = currentDate;
	}

	
	@DynamoDBAttribute(attributeName="id")
	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}
	@DynamoDBHashKey(attributeName ="uid")
	@DynamoDBGeneratedUuid(DynamoDBAutoGenerateStrategy.CREATE)
	public String getUid() {
		return uid;
	}


	public void setUid(String uid) {
		this.uid = uid;
	}

	@DynamoDBAttribute(attributeName="title")
	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}

	@DynamoDBAttribute(attributeName="description")
	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}

	@DynamoDBAttribute(attributeName="tags")
	public String getTags() {
		return tags;
	}


	public void setTags(String tags) {
		this.tags = tags;
	}

	@DynamoDBAttribute(attributeName="date")
	public String getDate() {
		return date;
	}


	public void setDate(String date) {
		this.date = date;
	}

	@DynamoDBAttribute(attributeName="username")
	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}

	
	
	
	
}
