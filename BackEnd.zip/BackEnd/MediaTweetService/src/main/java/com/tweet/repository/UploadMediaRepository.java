package com.tweet.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tweet.entity.UploadMedia;

@Repository
public interface UploadMediaRepository extends CrudRepository<UploadMedia, Integer> {

	public List<UploadMedia> getByUid(int uid);
}
