package com.tweet.entity;

import java.util.Random;


import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAutoGenerateStrategy;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBGeneratedUuid;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName="user")
public class User {


	private String id;
	private String fname;
	private String lname;
	private String username;
	private String password;
	private String email;
	private String profilepic;
	public User( ) {
//		super();
//		Random rand = new Random();
//		int resRandom = rand.nextInt((9999 - 100) + 1) + 10;
//		this.id = resRandom;
	}
	public User(String id, String fname, String lname, String username, String password, String email, String profilepic) {
		super();
		this.id = id;
		this.fname = fname;
		this.lname = lname;
		this.username = username;
		this.password = password;
		this.email = email;
		this.profilepic = profilepic;
	}
	@DynamoDBHashKey(attributeName ="id")
	//@DynamoDBGeneratedUuid(DynamoDBAutoGenerateStrategy.CREATE)
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	@DynamoDBAttribute(attributeName="fname")
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	@DynamoDBAttribute(attributeName="lname")
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	@DynamoDBAttribute(attributeName="username")
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	@DynamoDBAttribute(attributeName="password")
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@DynamoDBAttribute(attributeName="email")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@DynamoDBAttribute(attributeName="profilepic")
	public String getProfilepic() {
		return profilepic;
	}
	public void setProfilepic(String profilepic) {
		this.profilepic = profilepic;
	}
	
	
	
}
