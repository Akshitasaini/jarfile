package com.tweet.repository;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tweet.entity.Login;
@Repository
@EnableScan
public interface LoginRepository extends CrudRepository<Login, Integer>{

	public Login getByUsername(String username);
	public Login findByUsernameAndPassword(String username, String password);
}
