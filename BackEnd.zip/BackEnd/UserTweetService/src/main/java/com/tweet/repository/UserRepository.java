package com.tweet.repository;


import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tweet.entity.User;

@Repository
@EnableScan
public interface UserRepository extends CrudRepository<User, Integer> {

	public User findByUsername(String username);
}
