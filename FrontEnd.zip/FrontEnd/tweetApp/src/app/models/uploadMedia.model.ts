export class uploadMediaModel {
    public id: Number;
    
    constructor(
        public url:String,
        public title: String,
        public description: String,
        public tags:String,
        public username: string
        

    

    ) { }
}